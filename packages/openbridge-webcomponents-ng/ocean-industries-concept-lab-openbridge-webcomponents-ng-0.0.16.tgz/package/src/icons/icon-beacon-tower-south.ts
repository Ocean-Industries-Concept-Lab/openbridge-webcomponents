import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiBeaconTowerSouth as ObiBeaconTowerSouthElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-beacon-tower-south.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-beacon-tower-south.js';

@Component({
  selector: 'obi-beacon-tower-south',
  template: '<ng-content></ng-content>',
})
export class ObiBeaconTowerSouth {
  private _el: ObiBeaconTowerSouthElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiBeaconTowerSouthElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

