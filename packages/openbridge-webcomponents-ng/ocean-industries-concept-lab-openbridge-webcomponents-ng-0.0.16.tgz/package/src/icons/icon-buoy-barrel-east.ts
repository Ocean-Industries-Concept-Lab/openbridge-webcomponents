import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiBuoyBarrelEast as ObiBuoyBarrelEastElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-buoy-barrel-east.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-buoy-barrel-east.js';

@Component({
  selector: 'obi-buoy-barrel-east',
  template: '<ng-content></ng-content>',
})
export class ObiBuoyBarrelEast {
  private _el: ObiBuoyBarrelEastElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiBuoyBarrelEastElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

