import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiCapacitor03On as ObiCapacitor03OnElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-capacitor-03-on.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-capacitor-03-on.js';

@Component({
  selector: 'obi-capacitor-03-on',
  template: '<ng-content></ng-content>',
})
export class ObiCapacitor03On {
  private _el: ObiCapacitor03OnElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiCapacitor03OnElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

