import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiBeaconGeneralWest as ObiBeaconGeneralWestElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-beacon-general-west.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-beacon-general-west.js';

@Component({
  selector: 'obi-beacon-general-west',
  template: '<ng-content></ng-content>',
})
export class ObiBeaconGeneralWest {
  private _el: ObiBeaconGeneralWestElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiBeaconGeneralWestElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

