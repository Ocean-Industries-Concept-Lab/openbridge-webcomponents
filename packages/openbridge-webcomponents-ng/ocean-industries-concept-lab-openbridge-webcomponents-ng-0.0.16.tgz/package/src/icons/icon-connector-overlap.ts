import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiConnectorOverlap as ObiConnectorOverlapElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-connector-overlap.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-connector-overlap.js';

@Component({
  selector: 'obi-connector-overlap',
  template: '<ng-content></ng-content>',
})
export class ObiConnectorOverlap {
  private _el: ObiConnectorOverlapElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiConnectorOverlapElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

