import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiBeaconGeneralConeDown as ObiBeaconGeneralConeDownElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-beacon-general-cone-down.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-beacon-general-cone-down.js';

@Component({
  selector: 'obi-beacon-general-cone-down',
  template: '<ng-content></ng-content>',
})
export class ObiBeaconGeneralConeDown {
  private _el: ObiBeaconGeneralConeDownElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiBeaconGeneralConeDownElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

