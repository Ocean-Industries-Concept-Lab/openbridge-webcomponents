import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiChartSearch as ObiChartSearchElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-chart-search.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-chart-search.js';

@Component({
  selector: 'obi-chart-search',
  template: '<ng-content></ng-content>',
})
export class ObiChartSearch {
  private _el: ObiChartSearchElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiChartSearchElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

