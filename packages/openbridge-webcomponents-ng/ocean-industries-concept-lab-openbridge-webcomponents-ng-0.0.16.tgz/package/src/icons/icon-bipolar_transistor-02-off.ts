import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiBipolar_transistor02Off as ObiBipolar_transistor02OffElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-bipolar_transistor-02-off.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-bipolar_transistor-02-off.js';

@Component({
  selector: 'obi-bipolar_transistor-02-off',
  template: '<ng-content></ng-content>',
})
export class ObiBipolar_transistor02Off {
  private _el: ObiBipolar_transistor02OffElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiBipolar_transistor02OffElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

