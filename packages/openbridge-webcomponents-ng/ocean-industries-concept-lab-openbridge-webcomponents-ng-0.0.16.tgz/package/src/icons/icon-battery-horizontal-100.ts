import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiBatteryHorizontal100 as ObiBatteryHorizontal100Element} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-battery-horizontal-100.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-battery-horizontal-100.js';

@Component({
  selector: 'obi-battery-horizontal-100',
  template: '<ng-content></ng-content>',
})
export class ObiBatteryHorizontal100 {
  private _el: ObiBatteryHorizontal100Element;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiBatteryHorizontal100Element>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

