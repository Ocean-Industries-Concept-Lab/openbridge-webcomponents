import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiAisAtonPhysicalIec as ObiAisAtonPhysicalIecElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-ais-aton-physical-iec.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-ais-aton-physical-iec.js';

@Component({
  selector: 'obi-ais-aton-physical-iec',
  template: '<ng-content></ng-content>',
})
export class ObiAisAtonPhysicalIec {
  private _el: ObiAisAtonPhysicalIecElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiAisAtonPhysicalIecElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

