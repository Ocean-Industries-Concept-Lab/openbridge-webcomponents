import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiBuoySphericalFlag as ObiBuoySphericalFlagElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-buoy-spherical-flag.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-buoy-spherical-flag.js';

@Component({
  selector: 'obi-buoy-spherical-flag',
  template: '<ng-content></ng-content>',
})
export class ObiBuoySphericalFlag {
  private _el: ObiBuoySphericalFlagElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiBuoySphericalFlagElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

