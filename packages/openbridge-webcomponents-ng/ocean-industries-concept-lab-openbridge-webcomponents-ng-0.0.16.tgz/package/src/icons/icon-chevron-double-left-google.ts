import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiChevronDoubleLeftGoogle as ObiChevronDoubleLeftGoogleElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-chevron-double-left-google.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-chevron-double-left-google.js';

@Component({
  selector: 'obi-chevron-double-left-google',
  template: '<ng-content></ng-content>',
})
export class ObiChevronDoubleLeftGoogle {
  private _el: ObiChevronDoubleLeftGoogleElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiChevronDoubleLeftGoogleElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

