import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiAisTargetSleepingNohdgcogSelectedIec as ObiAisTargetSleepingNohdgcogSelectedIecElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-ais-target-sleeping-nohdgcog-selected-iec.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-ais-target-sleeping-nohdgcog-selected-iec.js';

@Component({
  selector: 'obi-ais-target-sleeping-nohdgcog-selected-iec',
  template: '<ng-content></ng-content>',
})
export class ObiAisTargetSleepingNohdgcogSelectedIec {
  private _el: ObiAisTargetSleepingNohdgcogSelectedIecElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiAisTargetSleepingNohdgcogSelectedIecElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

