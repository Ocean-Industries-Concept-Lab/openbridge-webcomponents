import {
  Component,
  ElementRef,
  NgZone,
  Input

} from '@angular/core';


import type {ObiBeaconTowerFlag as ObiBeaconTowerFlagElement} from '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-beacon-tower-flag.js';
import '@ocean-industries-concept-lab/openbridge-webcomponents/dist/icons/icon-beacon-tower-flag.js';

@Component({
  selector: 'obi-beacon-tower-flag',
  template: '<ng-content></ng-content>',
})
export class ObiBeaconTowerFlag {
  private _el: ObiBeaconTowerFlagElement;
  private _ngZone: NgZone;

  constructor(
    e: ElementRef<ObiBeaconTowerFlagElement>,
    ngZone: NgZone
  ) {
    this._el = e.nativeElement;
    this._ngZone = ngZone;
    
  }

  
  @Input()
  set useCssColor(v: boolean) {
    this._ngZone.runOutsideAngular(() => (this._el.useCssColor = v));
  }

  get useCssColor() {
    return this._el.useCssColor;
  }
  

  
}

