/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing with events
 */
import ts from 'typescript';
import { Event } from '../model.js';
import { AnalyzerInterface } from '../model.js';
/**
 * Returns an array of analyzer `Event` models for the given
 * ts.ClassDeclaration.
 */
export declare const addEventsToMap: (tag: ts.JSDocTag, events: Map<string, Event>, analyzer: AnalyzerInterface) => void;
//# sourceMappingURL=events.d.ts.map