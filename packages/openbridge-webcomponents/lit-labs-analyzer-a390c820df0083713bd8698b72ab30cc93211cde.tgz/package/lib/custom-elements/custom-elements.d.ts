/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing native custom elements (i.e. `HTMLElement`)
 * subclasses.
 */
import type ts from 'typescript';
import { AnalyzerInterface, CustomElementDeclaration, Event, NamedDescribed } from '../model.js';
export type CustomElementClassDeclaration = ts.ClassDeclaration & {
    _customElementBrand: never;
};
export declare const isCustomElementSubclass: (node: ts.Node, analyzer: AnalyzerInterface) => node is CustomElementClassDeclaration;
export declare const getTagName: (node: ts.ClassDeclaration | ts.ClassExpression, analyzer: AnalyzerInterface) => string | undefined;
/**
 * Parses element metadata from jsDoc tags from a LitElement declaration into
 * Maps of <name, info>.
 */
export declare const getJSDocData: (node: ts.ClassDeclaration, analyzer: AnalyzerInterface) => {
    events: Map<string, Event>;
    slots: Map<string, NamedDescribed>;
    cssProperties: Map<string, NamedDescribed>;
    cssParts: Map<string, NamedDescribed>;
    deprecated?: string | boolean | undefined;
    description?: string | undefined;
    summary?: string | undefined;
};
export declare const getCustomElementDeclaration: (node: CustomElementClassDeclaration, analyzer: AnalyzerInterface, isMixinClass?: boolean) => CustomElementDeclaration;
//# sourceMappingURL=custom-elements.d.ts.map