/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export declare const DiagnosticCode: {
    /**
     * This is the default error code and doesn't indicate any specific error.
     *
     * We start numbering from 548000 to avoid collisions with other projects.
     */
    readonly UNKNOWN: 548000;
    /**
     * This code represents a situation where ordinary and otherwise-valid code
     * is not yet supported in the Lit analyzer. We should aim to remove uses of
     * this code.
     */
    readonly UNSUPPORTED: 548001;
};
export type DiagnosticCode = (typeof DiagnosticCode)[keyof typeof DiagnosticCode];
//# sourceMappingURL=diagnostic-code.d.ts.map