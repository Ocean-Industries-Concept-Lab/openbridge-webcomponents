/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { AbsolutePath } from './paths.js';
import { Analyzer } from './analyzer.js';
export interface AnalyzerOptions {
    /**
     * Glob of source files to exclude from project during analysis.
     *
     * Useful for excluding things source like test folders that might otherwise
     * be included in a project's tsconfig.
     */
    exclude?: string[];
}
/**
 * Returns an analyzer for a Lit npm package based on a filesystem path.
 *
 * The path may specify a package root folder, or a specific tsconfig file. When
 * specifying a folder, if no tsconfig.json file is found directly in the root
 * folder, the project will be analyzed as JavaScript.
 */
export declare const createPackageAnalyzer: (packagePath: AbsolutePath, options?: AnalyzerOptions) => Analyzer;
//# sourceMappingURL=package-analyzer.d.ts.map