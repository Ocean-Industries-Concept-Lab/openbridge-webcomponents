/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { AnalyzerInterface } from './model.js';
/**
 * An absolute path
 */
export type AbsolutePath = string & {
    __absolutePathBrand: never;
};
/**
 * A path relative to a package root
 */
export type PackagePath = string & {
    __packagePathBrand: never;
};
/**
 * Convert an absolute path to a package-relative path
 */
export declare const absoluteToPackage: (path: AbsolutePath, packageRoot: AbsolutePath, seperator: string) => PackagePath;
export declare const resolveExtension: (path: AbsolutePath, analyzer: AnalyzerInterface, extensions?: string[]) => string;
//# sourceMappingURL=paths.d.ts.map