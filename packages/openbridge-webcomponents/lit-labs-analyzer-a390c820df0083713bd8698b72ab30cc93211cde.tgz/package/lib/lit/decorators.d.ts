/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing ReactiveElement decorators.
 */
import type ts from 'typescript';
export type TypeScript = typeof ts;
export declare const isCustomElementDecorator: (ts: TypeScript, decorator: ts.Decorator) => decorator is CustomElementDecorator;
/**
 * A narrower type for ts.Decorator that represents the shape of an analyzable
 * `@customElement('x')` callsite.
 */
export interface CustomElementDecorator extends ts.Decorator {
    readonly expression: ts.CallExpression;
}
export declare const getPropertyDecorator: (ts: TypeScript, declaration: ts.PropertyDeclaration) => PropertyDecorator | undefined;
/**
 * A narrower type for ts.Decorator that represents the shape of an analyzable
 * `@customElement('x')` callsite.
 */
interface PropertyDecorator extends ts.Decorator {
    readonly expression: ts.CallExpression;
}
/**
 * Gets the property options object from a `@property()` decorator callsite.
 *
 * Only works with an object literal passed as the first argument.
 */
export declare const getPropertyOptions: (ts: TypeScript, decorator: PropertyDecorator) => ts.ObjectLiteralExpression | undefined;
export {};
//# sourceMappingURL=decorators.d.ts.map