/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing reactive property declarations
 */
import type ts from 'typescript';
import { LitClassDeclaration } from './lit-element.js';
import { ReactiveProperty, AnalyzerInterface } from '../model.js';
export type TypeScript = typeof ts;
export declare const getProperties: (classDeclaration: LitClassDeclaration, analyzer: AnalyzerInterface) => Map<string, ReactiveProperty>;
/**
 * Gets the `attribute` property of a property options object as a string.
 *
 * The attribute value returned is the value that is used at runtime by
 * ReactiveElement, not the raw option. If the attribute property option is
 * not given or is `true`, the lower-cased property name is used. If the
 * attribute property option is `false`, `undefined` is returned.
 */
export declare const getPropertyAttribute: (ts: TypeScript, optionsNode: ts.ObjectLiteralExpression | undefined, propertyName: string) => string | undefined;
/**
 * Gets the `type` property of a property options object as a string.
 *
 * Note: A string is returned as a convenience so we don't have to compare
 * the type value against a known set of TS references for String, Number, etc.
 *
 * If a non-default converter is used, the types might not mean the same thing,
 * but we might not be able to realistically support custom converters.
 */
export declare const getPropertyType: (ts: TypeScript, obj: ts.ObjectLiteralExpression | undefined) => string | undefined;
/**
 * Gets the `reflect` property of a property options object as a boolean.
 */
export declare const getPropertyReflect: (ts: TypeScript, obj: ts.ObjectLiteralExpression | undefined) => boolean;
/**
 * Gets the `converter` property of a property options object.
 */
export declare const getPropertyConverter: (ts: TypeScript, obj: ts.ObjectLiteralExpression | undefined) => ts.PropertyAssignment | undefined;
//# sourceMappingURL=properties.d.ts.map