/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing LitElement (and ReactiveElement) declarations.
 */
import type ts from 'typescript';
import { LitElementDeclaration, AnalyzerInterface } from '../model.js';
export type TypeScript = typeof ts;
/**
 * Gets an analyzer LitElementDeclaration object from a ts.ClassDeclaration
 * (branded as LitClassDeclaration).
 */
export declare const getLitElementDeclaration: (declaration: LitClassDeclaration, analyzer: AnalyzerInterface, isMixinClass?: boolean) => LitElementDeclaration;
/**
 * This type identifies a ClassDeclaration as one that inherits from LitElement.
 *
 * It lets isLitElement function as a type predicate that returns whether or
 * not its argument is a LitElement such that when it returns false TypeScript
 * doesn't infer that the argument is not a ClassDeclaration.
 */
export type LitClassDeclaration = ts.ClassDeclaration & {
    __litBrand: never;
};
/**
 * Returns true if `node` is a ClassLikeDeclaration that extends LitElement.
 */
export declare const isLitElementSubclass: (node: ts.Node, analyzer: AnalyzerInterface) => node is LitClassDeclaration;
/**
 * Returns the tagname associated with a LitClassDeclaration
 * @param declaration
 * @returns
 */
export declare const getTagName: (declaration: LitClassDeclaration, analyzer: AnalyzerInterface) => string | undefined;
//# sourceMappingURL=lit-element.d.ts.map