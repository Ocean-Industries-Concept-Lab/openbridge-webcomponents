/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { type DefaultTreeAdapterTypes, type Token } from 'parse5';
import type ts from 'typescript';
export { isCommentNode, isDocumentFragment, isElementNode, isTextNode, } from '@parse5/tools';
type TypeScript = typeof ts;
export type Attribute = Token.Attribute;
export type ChildNode = DefaultTreeAdapterTypes.ChildNode;
export type CommentNode = DefaultTreeAdapterTypes.CommentNode;
export type DocumentFragment = DefaultTreeAdapterTypes.DocumentFragment;
export type Element = DefaultTreeAdapterTypes.Element;
export type Node = DefaultTreeAdapterTypes.Node;
export type TextNode = DefaultTreeAdapterTypes.TextNode;
export type ElementLocation = Token.ElementLocation;
/**
 * Returns true if the given node is a tagged template expression with the
 * lit-html template tag.
 */
export declare const isLitHtmlTaggedTemplateExpression: (node: ts.Node, ts: TypeScript, checker: ts.TypeChecker) => node is ts.TaggedTemplateExpression;
export declare const PartType: {
    readonly ATTRIBUTE: 1;
    readonly CHILD: 2;
    readonly PROPERTY: 3;
    readonly BOOLEAN_ATTRIBUTE: 4;
    readonly EVENT: 5;
    readonly ELEMENT: 6;
};
export type PartType = (typeof PartType)[keyof typeof PartType];
export type PartInfo = SinglePartInfo | AttributePartInfo;
interface BasePartInfo {
    valueIndex: number;
}
export interface SinglePartInfo extends BasePartInfo {
    type: typeof PartType.CHILD | typeof PartType.ELEMENT;
    expression: ts.Expression;
}
export interface AttributePartInfo extends BasePartInfo {
    type: typeof PartType.ATTRIBUTE | typeof PartType.BOOLEAN_ATTRIBUTE | typeof PartType.PROPERTY | typeof PartType.EVENT;
    prefix: string | undefined;
    name: string;
    strings: string[];
    expressions: Array<ts.Expression>;
}
/**
 * Checks if the parse5 comment node is a marker for a lit-html child part. If
 * true, the node will have a `litPart` property with the part info object.
 */
export declare const hasChildPart: (node: CommentNode) => node is LitTemplateCommentNode;
/**
 * Retrieves the TypeScript Expression node for a parse5 comment node, if the
 * comment node is a lit-html child part marker.
 */
export declare const getChildPartExpression: (node: CommentNode, ts: TypeScript) => ts.Expression | undefined;
export declare const hasAttributePart: (node: Attribute) => node is LitTemplateAttribute;
export type LitTemplateNode = Node & {
    litNodeIndex: number;
};
/**
 * A parsed lit-html template. This extends a parse5 DocumentFragment with
 * additional properties to describe the lit-html parts and the original
 * TypeScript tagged-template node that the template was parsed from.
 */
export interface LitTemplate extends DocumentFragment {
    /**
     * The original TypeScript node that this template was parsed from.
     */
    tsNode: ts.TaggedTemplateExpression;
    /**
     * The template strings that would be created from this expression at runtime.
     * This is an array of strings, with the raw property set to the same array.
     */
    strings: TemplateStringsArray;
    /**
     * The template parts, including child, attribute, event, and property
     * bindings.
     */
    parts: Array<PartInfo>;
}
export interface LitTemplateCommentNode extends CommentNode {
    /**
     * If this comment is a marker for a child part, this property will be set to
     * the ParInfo for that part.
     */
    litPart?: SinglePartInfo;
    /**
     * The depth-first index of this node in the template.
     */
    litNodeIndex: number;
}
export interface LitTemplateElement extends Element {
    litNodeIndex: number;
}
export interface LitTemplateAttribute extends Attribute {
    litPart: PartInfo;
}
/**
 * Returns all lit-html tagged template expressions in the given source file.
 */
export declare const getLitTemplateExpressions: (sourceFile: ts.SourceFile, ts: TypeScript, checker: ts.TypeChecker) => Array<ts.TaggedTemplateExpression>;
/**
 * Parses a lit-html tagged template expression into a {@linkcode LitTemplate}.
 *
 * {@linkcode LitTemplate} is a parse5 DocumentFragment with additional
 * properties to describe the lit-html parts.
 */
export declare const parseLitTemplate: (templateNode: ts.TaggedTemplateExpression, ts: TypeScript, _checker: ts.TypeChecker) => LitTemplate;
//# sourceMappingURL=template.d.ts.map