import type ts from 'typescript';
type TypeScript = typeof ts;
/**
 * Returns true if this node is an import declaration for a module known to
 * export the Lit html template tag.
 */
export declare const isLitHtmlImportDeclaration: (node: ts.Node, ts: TypeScript) => node is ts.ImportDeclaration;
/**
 * Returns true if the specifier is known to export the Lit html template tag.
 *
 * This can be used in a heuristic to determine if a template is a lit-html
 * template.
 */
export declare const isKnownLitHtmlModuleSpecifier: (specifier: string) => boolean;
/**
 * Resolve a common pattern of using the `html` identifier of a lit namespace
 * import.
 *
 * E.g.:
 *
 * ```ts
 * import * as identifier from 'lit';
 * identifier.html`<p>I am compiled!</p>`;
 * ```
 */
export declare const isResolvedPropertyAccessExpressionLitHtmlNamespace: (node: ts.PropertyAccessExpression, ts: TypeScript, checker: ts.TypeChecker) => boolean;
export {};
//# sourceMappingURL=modules.d.ts.map