/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import type ts from 'typescript';
import { AnalyzerInterface, LocalNameOrReference, Reference } from './model.js';
/**
 * Returns a ts.Symbol for a name in scope at a given location in the AST.
 * TODO(kschaaf): There are ~1748 symbols in scope of a typical hello world,
 * due to DOM globals. Perf might become an issue here.
 */
export declare const getSymbolForName: (name: string, location: ts.Node, analyzer: AnalyzerInterface) => ts.Symbol | undefined;
/**
 * Returns an analyzer `Reference` object for the given identifier.
 *
 * If the symbol's declaration was imported, the Reference will be based on
 * the import's module specifier; otherwise the Reference will point to the
 * current module being analyzed.
 */
export declare const getReferenceForIdentifier: (identifier: ts.Identifier, analyzer: AnalyzerInterface) => Reference | undefined;
/**
 * Returns an analyzer `Reference` model for the given ts.Symbol.
 *
 * If the symbol's declaration was imported, the Reference will be based on
 * the import's module specifier; otherwise the Reference will point to the
 * current module being analyzed.
 */
export declare function getReferenceForSymbol(symbol: ts.Symbol, location: ts.Node, analyzer: AnalyzerInterface): Reference | undefined;
/**
 * Returns a `Reference` for a symbol that was imported.
 *
 * There are 4 main categories of imports we cover:
 *
 * 1. A symbol imported from a URL. The declaration will be an
 *    ImportModuleSpecifier and its module path will be parsable as a URL.
 *
 * 2. A symbol imported from a relative file within this package. The
 *    declaration will be an ImportModuleSpecifier and its module path will
 *    start with a '.'
 *
 * 3. A symbol imported from an absolute path. The declaration will be an
 *    ImportModuleSpecifier and its module path will start with a '/' This is a
 *    weird case to cover in the analyzer because it isn't portable.
 *
 * 4. A symbol imported from an external package. The declaration will be an
 *    ImportModuleSpecifier and its module path will not start with a '.'
 */
export declare const getImportReference: (specifier: string, location: ts.Node, name: string, analyzer: AnalyzerInterface) => Reference;
/**
 * Returns a `Reference` for a symbol that was imported.
 */
export declare const getImportReferenceForSpecifierExpression: (specifierExpression: ts.Expression, name: string, analyzer: AnalyzerInterface) => Reference;
/**
 * For a given export clause and (optional) specifier from an export statement,
 * returns an array of objects mapping the export name to a
 * LocalNameOrReference, which is a string name that can be looked up directly
 * in `getDeclaration()` of the declaring module for local declarations, or a
 * `Reference` in the case of re-exported declarations.
 *
 * For example:
 * ```
 *   import {a} from 'foo';
 *   const b = 'b';
 *   const c = 'c';
 *   export {a as x, b as y, c};
 * ```
 * This would return (using pseudo-code for Reference objects):
 * ```
 * [
 *   {name: 'x', reference: new Reference('a', 'foo')},
 *   {name: 'y', reference: 'b'},
 *   {name: 'c', reference: 'c'},
 * ]
 * ```
 *
 * This also handles explicit re-export syntax, which all become References:
 * ```
 *   export {a as x, b as y, c} from 'foo';
 * ```
 *
 * Finally, this handles namespace exports, which become a single Reference:
 * ```
 *   export * as ns from 'foo';
 * ```
 * becomes:
 * ```
 *   [{name: 'ns', reference: new Reference('*', 'foo')}]
 * ```
 */
export declare const getExportReferences: (exportClause: ts.NamedExportBindings, moduleSpecifier: ts.Expression | undefined, analyzer: AnalyzerInterface) => Array<{
    exportName: string;
    decNameOrRef: LocalNameOrReference;
}>;
/**
 * Returns the specifier string from a specifier expression.
 *
 * For a given import statement:
 * ```
 * import {foo} from 'foo/bar.js';
 * ```
 * The specifierExpression is the string literal 'foo/bar.js' whose getText()
 * includes the quotes. This function returns the string value without the
 * quotes.
 */
export declare const getSpecifierString: (specifierExpression: ts.Expression) => string;
//# sourceMappingURL=references.d.ts.map