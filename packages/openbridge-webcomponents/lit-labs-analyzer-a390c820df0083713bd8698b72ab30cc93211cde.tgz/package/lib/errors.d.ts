/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import type ts from 'typescript';
import { DiagnosticCode } from './diagnostic-code.js';
export type TypeScript = typeof ts;
export interface DiagnosticOptions {
    typescript: TypeScript;
    node: ts.Node;
    message: string;
    category?: ts.DiagnosticCategory;
    code?: DiagnosticCode | undefined;
}
export declare const createDiagnostic: ({ typescript, node, message, category, code, }: DiagnosticOptions) => {
    file: ts.SourceFile;
    start: number;
    length: number;
    category: ts.DiagnosticCategory;
    code: DiagnosticCode;
    messageText: string;
};
//# sourceMappingURL=errors.d.ts.map