/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import type ts from 'typescript';
import { Type, AnalyzerInterface } from './model.js';
export type TypeScript = typeof ts;
/**
 * Returns an analyzer `Type` object for the given type string,
 * evaluated at the given location.
 *
 * Used for parsing types from JSDoc.
 */
export declare const getTypeForTypeString: (typeString: string, location: ts.Node, analyzer: AnalyzerInterface) => Type | undefined;
/**
 * Returns an analyzer `Type` object for the given AST node.
 */
export declare const getTypeForNode: (node: ts.Node, analyzer: AnalyzerInterface) => Type;
/**
 * Converts a ts.Type into an analyzer Type object (which wraps
 * the ts.Type, but also provides analyzer Reference objects).
 */
export declare const getTypeForType: (type: ts.Type, location: ts.Node, analyzer: AnalyzerInterface) => Type;
//# sourceMappingURL=types.d.ts.map