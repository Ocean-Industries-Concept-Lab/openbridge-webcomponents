/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Helper utilities for analyzing declarations
 */
import type ts from 'typescript';
import { Privacy } from './model.js';
export type TypeScript = typeof ts;
export declare const hasModifier: (ts: TypeScript, node: ts.HasModifiers, modifier: ts.SyntaxKind) => boolean;
export declare const hasExportModifier: (ts: TypeScript, node: ts.HasModifiers) => boolean;
export declare const hasDefaultModifier: (ts: TypeScript, node: ts.HasModifiers) => boolean;
export declare const hasStaticModifier: (ts: TypeScript, node: ts.HasModifiers) => boolean;
export declare const hasPrivateModifier: (ts: TypeScript, node: ts.HasModifiers) => boolean;
export declare const hasProtectedModifier: (ts: TypeScript, node: ts.HasModifiers) => boolean;
export declare const getPrivacy: (ts: TypeScript, node: ts.Node) => Privacy;
export declare const getBaseTypes: (type: ts.Type) => ts.BaseType[];
//# sourceMappingURL=utils.d.ts.map