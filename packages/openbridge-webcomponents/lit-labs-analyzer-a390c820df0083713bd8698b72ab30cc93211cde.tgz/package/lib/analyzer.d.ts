/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import type ts from 'typescript';
import { AnalyzerInterface, Module, Package, PackageJson } from './model.js';
import { AbsolutePath } from './paths.js';
export { PackageJson };
export type TypeScript = typeof ts;
export interface AnalyzerInit {
    typescript: TypeScript;
    getProgram: () => ts.Program;
    fs: AnalyzerInterface['fs'];
    path: AnalyzerInterface['path'];
    basePath?: AbsolutePath;
}
/**
 * An analyzer for Lit typescript modules.
 */
export declare class Analyzer implements AnalyzerInterface {
    readonly moduleCache: Map<AbsolutePath, Module>;
    private readonly _getProgram;
    readonly typescript: TypeScript;
    readonly fs: AnalyzerInterface['fs'];
    readonly path: AnalyzerInterface['path'];
    private _commandLine;
    private readonly diagnostics;
    constructor(init: AnalyzerInit);
    get program(): ts.Program;
    get commandLine(): ts.ParsedCommandLine;
    getModule(modulePath: AbsolutePath): Module;
    getPackage(): Package;
    addDiagnostic(diagnostic: ts.Diagnostic): void;
    getDiagnostics(): Generator<ts.Diagnostic, void, unknown>;
}
/**
 * Extracts a `ts.ParsedCommandLine` (essentially, the key bits of a
 * `tsconfig.json`) from the analyzer's `ts.Program`.
 *
 * The `ts.getOutputFileNames()` function must be passed a
 * `ts.ParsedCommandLine`; since not all usages of the analyzer create the
 * program directly from a tsconfig (plugins get passed the program only),
 * this allows backing the `ParsedCommandLine` out of an existing program.
 */
export declare const getCommandLineFromProgram: (analyzer: Analyzer) => ts.ParsedCommandLine;
//# sourceMappingURL=analyzer.d.ts.map