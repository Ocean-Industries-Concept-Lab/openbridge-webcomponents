/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing variable declarations
 */
import type ts from 'typescript';
import { VariableDeclaration, AnalyzerInterface, DeclarationInfo } from '../model.js';
export type TypeScript = typeof ts;
/**
 * Returns name and model factories for all variable
 * declarations in a variable statement.
 */
export declare const getVariableDeclarationInfo: (statement: ts.VariableStatement, analyzer: AnalyzerInterface) => DeclarationInfo[];
/**
 * Returns declaration info & factory for a default export assignment.
 */
export declare const getExportAssignmentVariableDeclarationInfo: (exportAssignment: ts.ExportAssignment, analyzer: AnalyzerInterface) => DeclarationInfo;
export declare const getEnumDeclarationInfo: (dec: ts.EnumDeclaration, analyzer: AnalyzerInterface) => {
    name: string;
    node: ts.EnumDeclaration;
    factory: () => VariableDeclaration;
    isExport: boolean;
};
//# sourceMappingURL=variables.d.ts.map