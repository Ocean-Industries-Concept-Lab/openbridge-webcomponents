/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { AnalyzerInterface, PackageInfo } from '../model.js';
import { AbsolutePath } from '../paths.js';
/**
 * Starting from a given module path, searches up until the nearest package.json
 * is found, returning that folder. If none is found, an error is thrown.
 */
export declare const getPackageRootForModulePath: (modulePath: AbsolutePath, analyzer: AnalyzerInterface) => AbsolutePath;
/**
 * Returns an analyzer `PackageInfo` model for the nearest package of the given
 * path.
 */
export declare const getPackageInfo: (path: AbsolutePath, analyzer: AnalyzerInterface) => PackageInfo;
//# sourceMappingURL=packages.d.ts.map