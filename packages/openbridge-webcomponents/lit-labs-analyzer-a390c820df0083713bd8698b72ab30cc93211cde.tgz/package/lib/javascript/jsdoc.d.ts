/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing JSDoc comments
 */
import type ts from 'typescript';
import { Described, TypedNamedDescribed, DeprecatableDescribed, AnalyzerInterface } from '../model.js';
export type TypeScript = typeof ts;
/**
 * @fileoverview
 *
 * Utilities for parsing JSDoc comments.
 */
/**
 * Returns true if given node has a JSDoc tag
 */
export declare const hasJSDocTag: (ts: TypeScript, node: ts.Node, tag: string) => boolean;
/**
 * Parses name, type, and description from JSDoc tag for things like `@fires`.
 *
 * Supports the following patterns following the tag (TS parses the tag for us):
 * * @fires event-name
 * * @fires event-name description
 * * @fires event-name - description
 * * @fires event-name: description
 * * @fires event-name {Type}
 * * @fires event-name {Type} description
 * * @fires event-name {Type} - description
 * * @fires event-name {Type}: description
 * * @fires {Type} event-name
 * * @fires {Type} event-name description
 * * @fires {Type} event-name - description
 * * @fires {Type} event-name: description
 * * @slot name
 * * @slot name description
 * * @slot name - description
 * * @slot name: description
 * * @cssProp [--name=default]
 * * @cssProp [--name=default] description
 * * @cssProp [--name=default] - description
 * * @cssProp [--name=default]: description
 * * @cssprop {<color>} [--name=default]
 * * @cssprop {<color>} [--name=default] description
 * * @cssprop {<color>} [--name=default] - description
 * * @cssprop {<color>} [--name=default]: description
 */
export declare const parseNamedTypedJSDocInfo: (tag: ts.JSDocTag, analyzer: AnalyzerInterface) => TypedNamedDescribed | undefined;
/**
 * Parses the description from JSDoc tag for things like `@return`.
 */
export declare const parseJSDocDescription: (tag: ts.JSDocTag, analyzer: AnalyzerInterface) => Described | undefined;
/**
 * Parse summary, description, and deprecated information from JSDoc comments on
 * a given node.
 */
export declare const parseNodeJSDocInfo: (node: ts.Node, analyzer: AnalyzerInterface) => DeprecatableDescribed;
/**
 * Parse summary, description, and deprecated information from JSDoc comments on
 * a given source file.
 */
export declare const parseModuleJSDocInfo: (sourceFile: ts.SourceFile, analyzer: AnalyzerInterface) => DeprecatableDescribed;
//# sourceMappingURL=jsdoc.d.ts.map