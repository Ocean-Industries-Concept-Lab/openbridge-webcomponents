/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing class declarations
 */
import type ts from 'typescript';
import { ClassDeclaration, AnalyzerInterface, DeclarationInfo, ClassHeritage, Reference, ClassField, ClassMethod } from '../model.js';
export type TypeScript = typeof ts;
/**
 * Returns an analyzer `ClassDeclaration` model for the given
 * ts.ClassLikeDeclaration.
 *
 * Note, the `docNode` may differ from the `declaration` in the case of a const
 * assignment to a class expression, as the JSDoc will be attached to the
 * VariableStatement rather than the class-like expression.
 */
export declare const getClassDeclaration: (declaration: ts.ClassLikeDeclaration, name: string, analyzer: AnalyzerInterface, docNode?: ts.Node, isMixinClass?: boolean) => ClassDeclaration;
/**
 * Returns the `fields` and `methods` of a class.
 */
export declare const getClassMembers: (declaration: ts.ClassLikeDeclaration, analyzer: AnalyzerInterface) => {
    fieldMap: Map<string, ClassField>;
    staticFieldMap: Map<string, ClassField>;
    methodMap: Map<string, ClassMethod>;
    staticMethodMap: Map<string, ClassMethod>;
};
/**
 * Returns name and model factory for a class declaration.
 */
export declare const getClassDeclarationInfo: (declaration: ts.ClassDeclaration, analyzer: AnalyzerInterface) => DeclarationInfo | undefined;
/**
 * Returns the superClass and any applied mixins for a given class declaration.
 */
export declare const getHeritage: (declaration: ts.ClassLikeDeclarationBase, analyzer: AnalyzerInterface, isMixinClass?: boolean) => ClassHeritage;
export declare const getHeritageFromExpression: (expression: ts.Expression, analyzer: AnalyzerInterface, isMixinClass?: boolean) => ClassHeritage;
export declare const getSuperClassAndMixins: (expression: ts.Expression, foundMixins: Reference[], analyzer: AnalyzerInterface) => Reference | undefined;
export declare const isConstructorFieldInitializer: (expression: ts.Expression, typescript: typeof ts) => expression is ConstructorFieldInitializer;
type ConstructorFieldInitializer = ts.AssignmentExpression<ts.EqualsToken> & {
    left: ts.PropertyAccessExpression & {
        expression: ts.ThisExpression;
    };
};
export declare const maybeGetAppliedMixin: (expression: ts.Expression, identifier: ts.Identifier, analyzer: AnalyzerInterface) => ClassDeclaration | undefined;
export {};
//# sourceMappingURL=classes.d.ts.map