/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing ES modules
 */
import type ts from 'typescript';
import { Module, AnalyzerInterface, PackageInfo, Declaration, ModuleInfo } from '../model.js';
import { AbsolutePath } from '../paths.js';
export type TypeScript = typeof ts;
/**
 * Returns the sourcePath, jsPath, and package.json contents of the containing
 * package for the given module path.
 *
 * This is a minimal subset of module information needed for constructing a
 * Reference object for a module.
 */
export declare const getModuleInfo: (modulePath: AbsolutePath, analyzer: AnalyzerInterface, packageInfo?: PackageInfo) => ModuleInfo;
/**
 * Returns an analyzer `Module` model for the given module path.
 */
export declare const getModule: (modulePath: AbsolutePath, analyzer: AnalyzerInterface, packageInfo?: PackageInfo) => Module;
/**
 * Resolves a module specifier expression node to an absolute path on disk.
 */
export declare const getPathForModuleSpecifierExpression: (specifierExpression: ts.Expression, analyzer: AnalyzerInterface) => AbsolutePath | undefined;
/**
 * Resolve a module specifier to an absolute path on disk.
 */
export declare const getPathForModuleSpecifier: (specifier: string, location: ts.Node, analyzer: AnalyzerInterface) => AbsolutePath | undefined;
/**
 * Returns the declaration for the named export of the given module path;
 * note that if the given module re-exported a declaration from another
 * module, references are followed to the concrete declaration, which is
 * returned.
 */
export declare const getResolvedExportFromSourcePath: (modulePath: AbsolutePath, name: string, analyzer: AnalyzerInterface) => Declaration;
//# sourceMappingURL=modules.d.ts.map