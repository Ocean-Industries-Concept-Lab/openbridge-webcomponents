/**
 * @license
 * Copyright 2024 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for working with mixins
 */
import type ts from 'typescript';
import { AnalyzerInterface, MixinDeclarationInit } from '../model.js';
/**
 * If the given variable declaration was a mixin function, returns a
 * MixinDeclaration initialisation object, otherwise returns undefined.
 *
 * The mixin logic requires a few important syntactic heuristics to be met in
 * order to be detected as a mixin:
 *
 * - a super class parameter (by any name) which is later used as a base class
 * - a function body (rather than an arrow function)
 * - an internal class which extends the previously mentioned super class parameter
 * - a return statement returning the class
 *
 * For example:
 *
 * ```
 * function MyMixin(superClass) {
 *   class MixedClass extends superClass {
 *     // ...
 *   }
 *   return MixedClass;
 * }
 * ```
 *
 * You can read more about this pattern in the TypeScript docs here:
 * https://www.typescriptlang.org/docs/handbook/mixins.html
 *
 * If the function is unannotated and does not match the above mixin shape, it
 * will silently just be analyzed as a simple function and not a mixin. However,
 * the `@mixin` annotation can be added to produce specific diagnostic errors
 * when a condition for being analyzed as a mixin is not met.
 */
export declare const maybeGetMixinFromFunctionLike: (fn: ts.FunctionLikeDeclaration, name: string, analyzer: AnalyzerInterface) => MixinDeclarationInit | undefined;
//# sourceMappingURL=mixins.d.ts.map