/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @fileoverview
 *
 * Utilities for analyzing function declarations
 */
import type ts from 'typescript';
import { AnalyzerInterface, DeclarationInfo, FunctionDeclaration, FunctionLikeInit } from '../model.js';
export type TypeScript = typeof ts;
export declare const getFunctionDeclarationInfo: (declaration: ts.FunctionDeclaration, analyzer: AnalyzerInterface) => DeclarationInfo | undefined;
/**
 * Returns an analyzer `FunctionDeclaration` model for the given
 * ts.FunctionLikeDeclaration.
 *
 * If this is a mixin function, the return value will be a `MixinDeclaration`
 * model instead.
 *
 * Note, the `docNode` may differ from the `declaration` in the case of a const
 * assignment to a class expression, as the JSDoc will be attached to the
 * VariableStatement rather than the class-like expression.
 */
export declare const getFunctionDeclaration: (declaration: ts.FunctionLikeDeclaration, name: string, analyzer: AnalyzerInterface, docNode?: ts.Node) => FunctionDeclaration;
/**
 * Returns information on FunctionLike nodes
 */
export declare const getFunctionLikeInfo: (node: ts.FunctionLikeDeclaration, name: string, analyzer: AnalyzerInterface) => FunctionLikeInit;
//# sourceMappingURL=functions.d.ts.map