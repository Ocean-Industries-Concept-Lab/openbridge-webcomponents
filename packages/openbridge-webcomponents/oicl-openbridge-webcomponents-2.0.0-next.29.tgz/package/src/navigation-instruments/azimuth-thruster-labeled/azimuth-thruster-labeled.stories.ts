import type {Meta, StoryObj} from '@storybook/web-components-vite';
import {
  AzimuthThrusterLabeledSize,
  ObcAzimuthThrusterLabeled,
} from './azimuth-thruster-labeled.js';
import './azimuth-thruster-labeled.js';
import {CommandStatus} from '../badge-command/badge-command.js';
import {AdviceType} from '../watch/advice.js';
import {widthDecorator} from '../../storybook-util.js';
import {PropellerType} from '../thruster/propeller.js';
import {TickmarkStyle} from '../watch/tickmark.js';

const meta: Meta<typeof ObcAzimuthThrusterLabeled> = {
  title: 'Instruments/Azimuth Thruster Labeled',
  tags: ['autodocs', '6.0'],
  component: 'obc-azimuth-thruster-labeled',
  args: {
    angle: 30,
    angleSetpoint: 40,
    thrust: 60,
    thrustSetpoint: 70,
    label: '3. Thruster',
    angleAdvices: [
      {minAngle: 20, maxAngle: 50, type: AdviceType.advice, hinted: true},
      {minAngle: 60, maxAngle: 100, type: AdviceType.caution, hinted: true},
    ],
    thrustAdvices: [
      {min: 20, max: 50, type: AdviceType.advice, hinted: true},
      {min: 75, max: 100, type: AdviceType.caution, hinted: true},
      {min: -100, max: -75, type: AdviceType.caution, hinted: true},
    ],
  },
  decorators: [widthDecorator],
  argTypes: {
    commandStatus: {
      options: Object.values(CommandStatus),
    },
    topPropeller: {
      options: Object.values(PropellerType),
    },
    bottomPropeller: {
      options: Object.values(PropellerType),
    },
    size: {
      options: Object.values(AzimuthThrusterLabeledSize),
    },
    width: {
      control: {type: 'range', min: 100, max: 2000, step: 1},
    },
    tickmarkStyle: {
      control: 'select',
      options: Object.values(TickmarkStyle),
    },
  },
} satisfies Meta<ObcAzimuthThrusterLabeled>;

export default meta;
type Story = StoryObj<ObcAzimuthThrusterLabeled>;

export const Medium: Story = {
  args: {
    size: AzimuthThrusterLabeledSize.medium,
    width: 384,
  },
};

export const Large: Story = {
  args: {
    size: AzimuthThrusterLabeledSize.large,
    width: 640,
  },
};

export const NotInCommand: Story = {
  args: {
    size: AzimuthThrusterLabeledSize.medium,
    width: 384,
    commandStatus: CommandStatus.NoCommand,
  },
};
