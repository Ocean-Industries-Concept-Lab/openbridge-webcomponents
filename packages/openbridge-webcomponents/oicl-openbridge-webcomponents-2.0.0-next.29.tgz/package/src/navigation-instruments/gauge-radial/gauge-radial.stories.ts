import type {Meta, StoryObj} from '@storybook/web-components-vite';
import {ObcGaugeRadial, ObcGaugeRadialType} from './gauge-radial.js';
import './gauge-radial.js';
import {widthDecorator} from '../../storybook-util.js';
import {AdviceType} from '../watch/advice.js';
import {TickmarkStyle} from '../watch/tickmark.js';
import {InstrumentState, Priority} from '../types.js';

const meta: Meta<typeof ObcGaugeRadial> = {
  title: 'Instruments/Gauge Radial',
  tags: ['6.0'],
  component: 'obc-gauge-radial',
  decorators: [widthDecorator],
  args: {
    width: 400,
  },
  argTypes: {
    state: {control: 'select', options: Object.values(InstrumentState)},
    priority: {control: 'select', options: Object.values(Priority)},
    tickmarksInside: {control: 'boolean'},
    tickmarkStyle: {
      control: 'select',
      options: Object.values(TickmarkStyle),
    },
    showLabels: {control: 'boolean'},
  },
} satisfies Meta<ObcGaugeRadial>;

export default meta;
type Story = StoryObj<ObcGaugeRadial>;

export const Positive: Story = {
  args: {
    value: 50,
    maxValue: 100,
    minValue: 0,
    type: ObcGaugeRadialType.filled,
  },
};

export const Negative: Story = {
  args: {
    value: -50,
    maxValue: 100,
    minValue: -100,
    type: ObcGaugeRadialType.filled,
  },
};

export const EnhancedFilled: Story = {
  args: {
    value: 50,
    maxValue: 100,
    minValue: 0,
    type: ObcGaugeRadialType.filled,
    state: InstrumentState.active,
    priority: Priority.enhanced,
    setpoint: 75,
  },
};

export const EnhancedBar: Story = {
  args: {
    value: 50,
    maxValue: 100,
    minValue: 0,
    type: ObcGaugeRadialType.bar,
    state: InstrumentState.active,
    priority: Priority.enhanced,
    setpoint: 75,
  },
};

export const EnhancedNeedle: Story = {
  args: {
    value: 50,
    maxValue: 100,
    minValue: 0,
    type: ObcGaugeRadialType.needle,
    state: InstrumentState.active,
    priority: Priority.enhanced,
    setpoint: 75,
  },
};

export const WithLabels: Story = {
  args: {
    value: 50,
    maxValue: 100,
    minValue: 0,
    type: ObcGaugeRadialType.filled,
    showLabels: true,
  },
};

export const WithAdvices: Story = {
  args: {
    value: 50,
    maxValue: 100,
    minValue: 0,
    type: ObcGaugeRadialType.filled,
    advices: [
      {
        minValue: 70,
        maxValue: 100,
        type: AdviceType.caution,
        hinted: true,
      },
      {
        minValue: 25,
        maxValue: 60,
        type: AdviceType.advice,
        hinted: true,
      },
    ],
  },
};

export const IrregularRange: Story = {
  args: {
    value: 300,
    minValue: 200,
    maxValue: 400,
    type: ObcGaugeRadialType.filled,
    showLabels: true,
    primaryTickmarkInterval: 50,
    secondaryTickmarkInterval: 25,
  },
};

export const WideAdviceSpan: Story = {
  args: {
    value: 320,
    minValue: 200,
    maxValue: 400,
    type: ObcGaugeRadialType.filled,
    showLabels: true,
    primaryTickmarkInterval: 50,
    secondaryTickmarkInterval: 25,
    advices: [
      {
        minValue: 230,
        maxValue: 390,
        type: AdviceType.caution,
        hinted: true,
      },
    ],
  },
};
