import type {Meta, StoryObj} from '@storybook/web-components-vite';
import {
  CompassDirection,
  HeadingPriorityElement,
  ObcHeading,
} from './heading.js';
import './heading.js';
import {widthDecorator} from '../../storybook-util.js';
import {AdviceType} from '../watch/advice.js';
import {Priority} from '../types.js';

const meta: Meta<typeof ObcHeading> = {
  title: 'Instruments/Heading',
  tags: ['6.0'],
  component: 'obc-heading',
  args: {
    width: 512,
    heading: 311,
    courseOverGround: 338,
    showLabels: true,
    headingAdvices: [
      {
        minAngle: 20,
        maxAngle: 50,
        type: AdviceType.advice,
        hinted: false,
      },
    ],
    headingSetpoint: 311,
    direction: CompassDirection.NorthUp,
    touching: false,
    priorityElements: [HeadingPriorityElement.hdg],
  },
  argTypes: {
    width: {control: {type: 'range', min: 32, max: 1028, step: 1}},
    heading: {control: {type: 'range', min: 0, max: 360, step: 1}},
    courseOverGround: {control: {type: 'range', min: 0, max: 360, step: 1}},
    headingSetpoint: {control: {type: 'range', min: 0, max: 360, step: 1}},
    direction: {
      control: {type: 'select'},
      options: Object.values(CompassDirection),
    },
    touching: {control: 'boolean'},
    showLabels: {control: 'boolean'},
    tickmarksInside: {control: 'boolean'},
    priority: {control: 'select', options: Object.values(Priority)},
    priorityElements: {
      control: 'multi-select',
      options: Object.values(HeadingPriorityElement),
    },
  },
  decorators: [widthDecorator],
} satisfies Meta<ObcHeading>;

export default meta;
type Story = StoryObj<ObcHeading>;

export const Primary: Story = {
  args: {
    headingSetpoint: undefined,
  },
};

export const Enhanced: Story = {
  args: {
    priority: Priority.enhanced,
    headingSetpoint: 311,
  },
};
