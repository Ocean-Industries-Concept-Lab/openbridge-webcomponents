import {LitElement, html, svg, SVGTemplateResult, unsafeCSS} from 'lit';
import componentStyle from './compass-flat.css?inline';
import {property, state} from 'lit/decorators.js';
import {Tickmark, TickmarkType} from '../watch-flat/tickmark-flat.js';
import '../watch-flat/watch-flat.js';
import {customElement} from '../../decorator.js';
import {Priority} from '../types.js';
import {
  RotType,
  LINEAR_DOT_ANGLE_SPACING,
  ROT_ZERO_DEADBAND_DEG,
} from '../rate-of-turn/rot-renderer.js';

export {RotType};

export enum CompassFlatPriorityElement {
  hdg = 'hdg',
  cog = 'cog',
  rot = 'rot',
}

export enum LabelPosition {
  top = -45,
  bottom = 50,
}

export enum LabelStyle {
  regular = 'var(--instrument-tick-mark-secondary-color)',
}

export interface Label {
  x: number;
  y: LabelPosition;
  text: string;
}

/**
 * `<obc-compass-flat>` — Horizontal strip compass with HDG/COG arrows and optional rate-of-turn indicator.
 *
 * Renders a flat (non-circular) compass strip that scrolls horizontally to
 * display the current heading. A filled HDG arrow sits at the center while a
 * hollow COG arrow is positioned at the angular difference. The strip
 * auto-scales its field of view so both arrows remain visible. Cardinal
 * labels (N, S, E, W) and tickmarks are generated at densities responsive to
 * the strip width.
 *
 * ## Features
 *
 * - **Auto-scaling FOV**: The visible compass range widens to keep both HDG
 *   and COG arrows in view, bounded by `minFOV` / `maxFOV`.
 * - **HDG / COG arrows**: Filled (HDG) and hollow (COG) arrow SVGs positioned
 *   along the strip.
 * - **FOV indicator**: Optional numeric labels showing the port/starboard
 *   bearing range and current heading.
 * - **Rate of turn**: Animated linear ROT indicator (spinning dots or
 *   horizontal bar) via `rotType`. When enabled, a bottom bar is added to
 *   the strip to house the indicator.
 * - **Color priority**: Per-element priority for HDG, COG, and ROT via
 *   `priorityElements`.
 *
 * @property {number} heading - Current heading in degrees.
 * @property {number} courseOverGround - Current COG in degrees.
 * @property {RotType|undefined} rotType - ROT display mode: `'dots'`, `'bar'`, or `undefined` (hidden).
 * @property {number|undefined} rateOfTurnDegreesPerMinute - Measured rate of turn in degrees per minute (positive = starboard). Drives the bar extent and (after `× rotDotAnimationFactor`) the dot animation.
 * @property {number} rotDotAnimationFactor - Visual amplification for the dot animation only. Default `18` (≈1 rpm at 20°/min).
 * @property {number} rotationsPerMinute - **Deprecated.** Use `rateOfTurnDegreesPerMinute` instead.
 * @property {number} rotMaxValue - Bar-extent reference value in **degrees per minute**. Default `60` per ES-TRIN 2025/1 Art. 3.02.
 * @property {number} rotArcExtent - Degrees of bar arc per max-value ROT (default 60).
 *
 * @ignition-base-height: 170px
 * @ignition-base-width: 512px
 */
@customElement('obc-compass-flat')
export class ObcCompassFlat extends LitElement {
  @property({type: Boolean}) FOVIndicator: boolean = false;
  @property({type: Number}) heading = 0;
  @property({type: Number}) courseOverGround = 0;
  @property({type: Number}) tickInterval = 5;
  @property({type: Number}) FOV = 45;
  @property({type: Number}) minFOV = 45;
  @property({type: Number}) maxFOV = 180;
  @property({type: String}) priority: Priority = Priority.regular;
  @property({type: Array, attribute: false})
  priorityElements: CompassFlatPriorityElement[] = [
    CompassFlatPriorityElement.hdg,
  ];
  @property({type: String}) rotType: RotType | undefined;
  /**
   * Measured rate of turn in degrees per minute (positive = starboard).
   * When `undefined`, falls back to the deprecated `rotationsPerMinute`.
   */
  @property({type: Number}) rateOfTurnDegreesPerMinute: number | undefined;
  /**
   * Visual amplification applied only to the spinning dot animation.
   */
  @property({type: Number}) rotDotAnimationFactor: number = 18;
  /**
   * @deprecated Use `rateOfTurnDegreesPerMinute` instead.
   */
  @property({type: Number}) rotationsPerMinute: number = 1;
  /**
   * Bar-extent reference value in **degrees per minute**. Default `60`
   * per ES-TRIN 2025/1 Art. 3.02.
   */
  @property({type: Number}) rotMaxValue: number = 60;
  @property({type: Number}) rotArcExtent: number = 60;
  @property({type: Boolean}) rotPortStarboard: boolean = false;
  @property({type: Number}) rotAtZeroDeadband: number = ROT_ZERO_DEADBAND_DEG;

  @state() private containerWidth = 0;
  @state() private maxContainerWidth = 0;

  private resizeObserver: ResizeObserver = new ResizeObserver((entries) => {
    for (const entry of entries) {
      // Made by chatGPT so that the text is inside the wrapper
      this.maxContainerWidth = -125.36 + 3.79 * entry.contentRect.height;
      this.containerWidth = Math.min(
        entry.contentRect.width,
        this.maxContainerWidth
      );
    }
  });

  override connectedCallback() {
    super.connectedCallback();
    this.resizeObserver.observe(this);
  }

  override disconnectedCallback() {
    super.disconnectedCallback();
    this.resizeObserver.unobserve(this);
  }

  generateLabels() {
    if (this.containerWidth < 192) {
      return [];
    } else if (this.containerWidth <= 300) {
      return [
        {x: -180, y: LabelPosition.top, text: 'S'},
        {x: -90, y: LabelPosition.top, text: 'W'},
        {x: 0, y: LabelPosition.top, text: 'N'},
        {x: 90, y: LabelPosition.top, text: 'E'},
        {x: 180, y: LabelPosition.top, text: 'S'},
        {x: 270, y: LabelPosition.top, text: 'W'},
        {x: 360, y: LabelPosition.top, text: 'N'},
        {x: 450, y: LabelPosition.top, text: 'E'},
        {x: 540, y: LabelPosition.top, text: 'S'},
      ];
    } else {
      return [
        {x: -180, y: LabelPosition.top, text: 'S'},
        {x: -135, y: LabelPosition.top, text: 'SW'},
        {x: -90, y: LabelPosition.top, text: 'W'},
        {x: -45, y: LabelPosition.top, text: 'NW'},
        {x: 0, y: LabelPosition.top, text: 'N'},
        {x: 45, y: LabelPosition.top, text: 'NE'},
        {x: 90, y: LabelPosition.top, text: 'E'},
        {x: 135, y: LabelPosition.top, text: 'SE'},
        {x: 180, y: LabelPosition.top, text: 'S'},
        {x: 225, y: LabelPosition.top, text: 'SW'},
        {x: 270, y: LabelPosition.top, text: 'W'},
        {x: 315, y: LabelPosition.top, text: 'NW'},
        {x: 360, y: LabelPosition.top, text: 'N'},
        {x: 405, y: LabelPosition.top, text: 'NE'},
        {x: 450, y: LabelPosition.top, text: 'E'},
        {x: 495, y: LabelPosition.top, text: 'SE'},
        {x: 540, y: LabelPosition.top, text: 'S'},
      ];
    }
  }

  private generateIntervalTickmarks(scale: number): Tickmark[] {
    const tickmarks: Tickmark[] = [];
    let cardinalInterval = 90;

    if (this.containerWidth > 300) {
      cardinalInterval = 45;
    } else if (this.containerWidth < 192) {
      cardinalInterval = 0;
    }

    // Guard against zero/negative/non-finite interval to prevent infinite loops
    if (
      !this.tickInterval ||
      this.tickInterval <= 0 ||
      !Number.isFinite(this.tickInterval)
    ) {
      return tickmarks;
    }

    for (
      let angle = -180;
      angle < this.maxFOV * 3;
      angle += this.tickInterval
    ) {
      if (cardinalInterval !== 0 && angle % cardinalInterval === 0) {
        continue;
      }
      tickmarks.push({angle: angle * scale, type: TickmarkType.secondary});
    }

    return tickmarks;
  }

  private generateCardinalTickmarks(
    scale: number,
    labels: Label[]
  ): Tickmark[] {
    const tickmarks: Tickmark[] = [];

    for (const label of labels) {
      tickmarks.push({angle: label.x * scale, type: TickmarkType.main});
    }

    return tickmarks;
  }

  private generateTickmarks(scale: number, labels: Label[]): Tickmark[] {
    return [
      ...this.generateCardinalTickmarks(scale, labels),
      ...this.generateIntervalTickmarks(scale),
    ];
  }

  private renderFOVIndicator(): SVGTemplateResult[] {
    const indicators: SVGTemplateResult[] = [];

    const maxAdjustment = 10;
    const minContainerWidth = 300;
    const maxContainerWidth = 512;

    let yAdjustment = 0;
    if (this.containerWidth < maxContainerWidth) {
      const widthRange = maxContainerWidth - minContainerWidth;
      const scaleFactor =
        (maxContainerWidth - this.containerWidth) / widthRange;
      yAdjustment = scaleFactor * maxAdjustment;
    }

    const y = LabelPosition.bottom + yAdjustment + (this.rotType ? 12 : 0);

    indicators.push(svg`
          <text x="-175" y=${y} class="label left" fill=${LabelStyle.regular}>
            ${-this.FOV}\u00B0
          </text>`);

    indicators.push(svg`
          <text x="0" y=${y} class="label" fill=${LabelStyle.regular}>
            ${this.heading}\u00B0
          </text>`);

    indicators.push(svg`
          <text x="175" y=${y} class="label right" fill=${LabelStyle.regular}>
            ${this.FOV}\u00B0
          </text>`);

    return indicators;
  }

  private priorityFor(element: CompassFlatPriorityElement): Priority {
    const selected = Array.isArray(this.priorityElements)
      ? this.priorityElements
      : [];
    return selected.includes(element) ? this.priority : Priority.regular;
  }

  private get _effectiveRotDegPerMin(): number {
    return this.rateOfTurnDegreesPerMinute ?? this.rotationsPerMinute;
  }

  private arrowColorFor(element: CompassFlatPriorityElement): string {
    return this.priorityFor(element) === Priority.enhanced
      ? 'var(--instrument-enhanced-secondary-color)'
      : 'var(--instrument-regular-secondary-color)';
  }

  private get HDGSvg(): SVGTemplateResult {
    return svg`<g transform="translate(-24, -74)">
          <path d="M36.7011 44.1445L36.6898 44.1379L36.6781 44.1318L24.2301 37.6823L24.0001 37.5631L23.7701 37.6823L11.3221 44.1318L11.3104 44.1379L11.2991 44.1445C9.25497 45.3438 6.78661 43.308 7.68828 41.0919L22.6036 4.43285C23.1096 3.18905 24.8906 3.18905 25.3967 4.43284L40.3119 41.0919C41.2136 43.308 38.7452 45.3438 36.7011 44.1445Z" fill="${this.arrowColorFor(CompassFlatPriorityElement.hdg)}" stroke="var(--border-silhouette-color)"/>
        </g>`;
  }

  private COGSvg(translation: number): SVGTemplateResult {
    return svg`
      <g transform="translate(${-24 + translation}, -74)">
        <path d="M31.9025 36.0262L33.1068 36.6502L32.5956 35.3938L24.4632 15.406L24.0001 14.2677L23.537 15.406L15.4046 35.3938L14.8935 36.6502L16.0978 36.0262L24.0001 31.9319L31.9025 36.0262ZM36.7011 44.1445L36.6898 44.1379L36.6781 44.1318L24.2301 37.6823L24.0001 37.5631L23.7701 37.6823L11.3221 44.1318L11.3104 44.1379L11.2991 44.1445C9.25497 45.3438 6.78661 43.308 7.68828 41.0919L22.6036 4.43285C23.1096 3.18905 24.8906 3.18905 25.3967 4.43284L40.3119 41.0919C41.2136 43.308 38.7452 45.3438 36.7011 44.1445Z" fill="${this.arrowColorFor(CompassFlatPriorityElement.cog)}" stroke="var(--border-silhouette-color)"/>
      </g>
    `;
  }

  override render() {
    let angleDiff = this.courseOverGround - this.heading;

    if (angleDiff > this.maxFOV) {
      angleDiff -= 360;
    } else if (angleDiff < -this.maxFOV) {
      angleDiff += 360;
    }

    this.FOV = Math.max(this.minFOV, Math.abs(angleDiff));

    const baseOffset = 5;
    const translationScale = (baseOffset * 35) / this.FOV;

    const translation = angleDiff * translationScale;
    const labels = this.generateLabels();
    const tickmarks = this.generateTickmarks(translationScale, labels);
    const scaledLabels = labels.map((l) => ({
      ...l,
      x: l.x * translationScale,
    }));

    const hasBottomBar = !!this.rotType;
    const arrowViewBoxY = hasBottomBar
      ? -128 + Math.round((12 * 384) / 352)
      : -128;
    const viewBox = `-192 ${arrowViewBoxY} 384 128`;

    return html`
      <div class="container" style="max-width:${this.maxContainerWidth}px">
        <obc-watch-flat
          .FOVIndicator=${this.FOVIndicator ? this.renderFOVIndicator() : []}
          .labels=${scaledLabels}
          .rotation=${this.heading}
          .tickmarks=${tickmarks}
          .tickmarkSpacing=${translationScale}
          .bottomBar=${!!this.rotType}
          .rotType=${this.rotType}
          .rotStartX=${0}
          .rotEndX=${(this._effectiveRotDegPerMin / (this.rotMaxValue || 1)) *
          this.rotArcExtent *
          translationScale}
          .rotDotSpacing=${LINEAR_DOT_ANGLE_SPACING * translationScale}
          .rateOfTurnDegreesPerMinute=${this.rateOfTurnDegreesPerMinute}
          .rotDotAnimationFactor=${this.rotDotAnimationFactor}
          .rotationsPerMinute=${this.rotationsPerMinute}
          .rotPriority=${this.priorityFor(CompassFlatPriorityElement.rot)}
          .rotPortStarboard=${this.rotPortStarboard}
          .rotAtZeroDeadband=${this.rotAtZeroDeadband * translationScale}
        ></obc-watch-flat>
        <svg viewBox=${viewBox} xmlns="http://www.w3.org/2000/svg">
          ${this.HDGSvg}${this.COGSvg(translation)}
        </svg>
      </div>
    `;
  }

  static override styles = unsafeCSS(componentStyle);
}

declare global {
  interface HTMLElementTagNameMap {
    'obc-compass-flat': ObcCompassFlat;
  }
}
