import type {Meta, StoryObj} from '@storybook/web-components-vite';
import {ObcHorizontalLine} from './horizontal-line.js';
import './horizontal-line.js';
import {crossDecorator} from '../../storybook-util.js';

const meta: Meta<typeof ObcHorizontalLine> = {
  title: 'Automation/Line/Horizontal Line',
  tags: ['autodocs'],
  component: 'obc-horizontal-line',
  decorators: [crossDecorator],
  argTypes: {
    medium: {
      options: ['normal', 'empty', 'water'],
      control: {type: 'radio'},
    },
    lineType: {
      options: ['fluid', 'electric', 'air', 'connector'],
      control: {type: 'radio'},
    },
  },
} satisfies Meta<ObcHorizontalLine>;

export default meta;
type Story = StoryObj<ObcHorizontalLine>;

export const Primary: Story = {
  args: {
    length: 3,
  },
};
