import type {Meta, StoryObj} from '@storybook/web-components-vite';
import {
  AutomationButtonDirection,
  AutomationButtonPositioning,
  AutomationButtonVariant,
  ObcAutomationButton,
} from './automation-button.js';
import {
  AutomationButtonReadoutStack,
  AutomationButtonReadoutStackSize,
} from '../../components/automation-button-readout-stack/automation-button-readout-stack.js';
import {AutomationButtonReadoutPosition} from './automation-button.js';
import './automation-button.js';
import {html} from 'lit';
import '../../icons/icon-twoway-digital-open.js';
import '../../icons/icon-twoway-digital-closed.js';
import '../../icons/icon-switch-horizontal-on.js';
import '../../icons/icon-switch-horizontal-off.js';
import '../../icons/icon-damper-horizontal-on.js';
import '../../icons/icon-damper-horizontal-off.js';
import '../../automation/automation-badge/automation-badge.js';
import '../../icons/icon-alert-off-google.js';
import '../../icons/icon-auto.js';
import '../../icons/icon-duty.js';
import '../../icons/icon-pump-on-horizontal.js';
import '../../icons/icon-pump-off-horizontal.js';
import '../valve-analog-three-way-icon/valve-analog-three-way-icon.js';
import '../../icons/icon-command-locked-f.js';
import {crossDecorator} from '../../storybook-util.js';
import {
  ObcAlertFrameStatus,
  ObcAlertFrameThickness,
  ObcAlertFrameType,
} from '../../components/alert-frame/alert-frame.js';
import {CircularProgressMode} from '../../building-blocks/circular-progress/circular-progress.js';

const meta: Meta<typeof ObcAutomationButton> = {
  title: 'Automation/Automation Devices/Automation Button',
  tags: ['autodocs', '6.0'],
  component: 'obc-automation-button',
  decorators: [crossDecorator],
  argTypes: {
    readoutPosition: {
      options: ['top', 'bottom', 'left', 'right'],
      control: {type: 'radio'},
    },
    readoutSize: {
      options: ['small', 'regular', 'enhanced'],
      control: {type: 'radio'},
    },
    alert: {
      control: {type: 'boolean'},
    },
    positioning: {
      options: Object.values(AutomationButtonPositioning),
      control: {type: 'select'},
    },
    variant: {
      options: Object.values(AutomationButtonVariant),
      control: {type: 'select'},
    },
    direction: {
      options: [
        'forward',
        'forward-fast',
        'forward-stopped',
        'backward',
        'backward-fast',
        'backward-stopped',
        'standby',
      ],
      control: {type: 'radio'},
    },
    progressMode: {
      options: Object.values(CircularProgressMode),
      control: {type: 'select'},
      if: {arg: 'progress'},
    },
    progressValue: {
      control: {type: 'range', min: 0, max: 100, step: 1},
      if: {arg: 'progress'},
    },
  },
  args: {
    showReadoutStack: true,
    showAlertCategoryIcon: true,
    variant: AutomationButtonVariant.regular,
    readoutPosition: AutomationButtonReadoutPosition.bottom,
    readoutSize: AutomationButtonReadoutStackSize.regular,
    positioning: AutomationButtonPositioning.point,
    showAlertIcon: true,
  },
  parameters: {
    // Overrides the default behavior and pauses the animation at the first frame at the component level for all stories.
    chromatic: {pauseAnimationAtEnd: false},
  },
} as Meta<typeof ObcAutomationButton>;

export default meta;
type Story = StoryObj<ObcAutomationButton>;

export const ValveOpen: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = '#0000';
    return html`<obc-automation-button
      state="open"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      .variant=${args.variant}
      .positioning=${args.positioning}
      .showAlertCategoryIcon=${args.showAlertCategoryIcon}
      .showAlertIcon=${args.showAlertIcon}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
    >
      <obi-twoway-digital-open
        usecsscolor
        slot="icon"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
      <obi-twoway-digital-open
        usecsscolor
        slot="icon-silhouette"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
    </obc-automation-button>`;
  },
};

export const ValveFlat: Story = {
  ...ValveOpen,
  args: {
    variant: AutomationButtonVariant.flat,
  },
};

export const ValveAlert: Story = {
  argTypes: {
    alertFrameType: {
      options: Object.values(ObcAlertFrameType),
      control: {
        type: 'select',
      },
    },
    alertFrameThickness: {
      options: Object.values(ObcAlertFrameThickness),
      control: {
        type: 'select',
      },
    },
    alertFrameStatus: {
      options: Object.values(ObcAlertFrameStatus),
      control: {
        type: 'select',
      },
    },
  },
  args: {
    alert: true,
    alertFrameType: ObcAlertFrameType.LargeSideFlip,
    alertFrameThickness: ObcAlertFrameThickness.Small,
    alertFrameStatus: ObcAlertFrameStatus.Alarm,
  },
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      .alertFrameStatus=${args.alertFrameStatus}
      .alertFrameThickness=${args.alertFrameThickness}
      .alertFrameType=${args.alertFrameType}
      .showAlertCategoryIcon=${args.showAlertCategoryIcon}
      .showAlertIcon=${args.showAlertIcon}
      .positioning=${args.positioning}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
    >
      <obi-twoway-digital-open
        usecsscolor
        slot="icon"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
      <obi-placeholder slot="alert-icon"></obi-placeholder>
      <div slot="alert-label">Label</div>
      <div slot="alert-timer">00:45</div>
    </obc-automation-button>`;
  },
};

export const ValveBadges: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      hasBadgeSpacer
      .positioning=${args.positioning}
    >
      <obi-twoway-digital-open
        usecsscolor
        slot="icon"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
      <obc-automation-badge slot="badge-top-right">
        <obi-alert-off-google></obi-alert-off-google>
        <obi-alert-off-google slot="icon-silhouette"></obi-alert-off-google>
      </obc-automation-badge>
      <obc-automation-badge slot="badge-top-left">
        <obi-auto></obi-auto>
        <obi-auto slot="icon-silhouette"></obi-auto>
      </obc-automation-badge>
      <obc-automation-badge slot="badge-bottom-left">
        <obi-duty></obi-duty>
        <obi-duty slot="icon-silhouette"></obi-duty>
      </obc-automation-badge>
      <obc-automation-badge slot="badge-bottom-right">
        <obi-command-locked-f></obi-command-locked-f>
        <obi-command-locked-f slot="icon-silhouette"></obi-command-locked-f>
      </obc-automation-badge>
    </obc-automation-button>`;
  },
};

export const ValveProgress: Story = {
  tags: ['skip-test'],
  args: {
    progress: true,
    progressMode: CircularProgressMode.indeterminate,
    progressValue: 0,
  },
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-twoway-digital-open
        usecsscolor
        slot="icon"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
    </obc-automation-button>`;
  },
};

export const ValveProgressDeterminate: Story = {
  tags: ['skip-test'],
  args: {
    progress: true,
    progressMode: CircularProgressMode.determinate,
    progressValue: 65,
  },
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-twoway-digital-open
        usecsscolor
        slot="icon"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
    </obc-automation-button>`;
  },
};

export const ValveProgressProgressive: Story = {
  tags: ['skip-test'],
  args: {
    progress: true,
    progressMode: CircularProgressMode.progressiveIndeterminate,
    progressValue: 40,
  },
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-twoway-digital-open
        usecsscolor
        slot="icon"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
    </obc-automation-button>`;
  },
};

export const SquareProgressDeterminate: Story = {
  tags: ['skip-test'],
  args: {
    progress: true,
    progressMode: CircularProgressMode.determinate,
    progressValue: 50,
    variant: AutomationButtonVariant.square,
  },
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .variant=${args.variant}
      .positioning=${args.positioning}
    >
      <obi-switch-horizontal-on
        usecsscolor
        slot="icon"
      ></obi-switch-horizontal-on>
    </obc-automation-button>`;
  },
};

export const ValveClosed: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="closed"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      .static=${args.static}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-twoway-digital-closed
        usecsscolor
        slot="icon"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-closed>
    </obc-automation-button>`;
  },
};

export const ValveClosedStatic: Story = {
  ...ValveClosed,
  args: {
    static: true,
  },
};

export const ValveNoLabels: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [];
    const tag: string | null = null;
    return html` <obc-automation-button
      state="open"
      .showReadoutStack=${false}
      .readouts=${readouts}
      .tag=${tag}
      .variant=${args.variant}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-twoway-digital-open
        usecsscolor
        slot="icon"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
      <obi-twoway-digital-open
        usecsscolor
        slot="icon-silhouette"
        style="display: block; transform: rotate(90deg); line-height: 0;"
      ></obi-twoway-digital-open>
    </obc-automation-button>`;
  },
};

export const SwitchOn: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [
      {type: 'state-on', value: 'On', hasIcon: true},
    ];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      variant="square"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-switch-horizontal-on
        usecsscolor
        slot="icon"
        style="display: block; line-height: 0;"
      ></obi-switch-horizontal-on>
    </obc-automation-button>`;
  },
};

export const SwitchOff: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [
      {type: 'state-off', value: 'Off', hasIcon: true},
    ];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="closed"
      variant="square"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-switch-horizontal-off
        usecsscolor
        slot="icon"
        style="display: block; line-height: 0;"
      ></obi-switch-horizontal-off>
    </obc-automation-button>`;
  },
};

export const DamperOn: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [
      {type: 'state-on', value: 'On', hasIcon: true},
    ];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      variant="square"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-damper-horizontal-on
        usecsscolor
        slot="icon"
        style="display: block; line-height: 0;"
      ></obi-damper-horizontal-on>
    </obc-automation-button>`;
  },
};

export const DamperOff: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [
      {type: 'state-off', value: 'Off', hasIcon: true},
    ];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="closed"
      variant="square"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-damper-horizontal-off
        usecsscolor
        slot="icon"
        style="display: block; line-height: 0;"
      ></obi-damper-horizontal-off>
    </obc-automation-button>`;
  },
};

export const DamperBadges: Story = {
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [
      {type: 'state-on', value: 'On', hasIcon: true},
    ];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      variant="square"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-damper-horizontal-on
        usecsscolor
        slot="icon"
        style="display: block; line-height: 0;"
      ></obi-damper-horizontal-on>
      <obc-automation-badge slot="badge-top-right">
        <obi-alert-off-google></obi-alert-off-google>
      </obc-automation-badge>
      <obc-automation-badge slot="badge-top-left">
        <obi-auto></obi-auto>
      </obc-automation-badge>
      <obc-automation-badge slot="badge-bottom-left">
        <obi-duty></obi-duty>
      </obc-automation-badge>
      <obc-automation-badge slot="badge-bottom-right">
        <obi-command-locked-f></obi-command-locked-f>
      </obc-automation-badge>
    </obc-automation-button>`;
  },
};

export const MotorOn: Story = {
  args: {
    direction: AutomationButtonDirection.forward,
  },
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [
      {type: 'state-on', value: 'On', hasIcon: true},
    ];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      variant="double"
      direction="forward"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      direction=${args.direction}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-pump-on-horizontal
        usecsscolor
        slot="icon"
        style="display: block; line-height: 0;"
      ></obi-pump-on-horizontal>
    </obc-automation-button>`;
  },
};

export const MotorOff: Story = {
  args: {
    direction: AutomationButtonDirection.forwardStopped,
  },
  render(args) {
    const readouts: AutomationButtonReadoutStack[] = [
      {type: 'state-off', value: 'Off', hasIcon: true},
    ];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="closed"
      variant="double"
      direction="forward-stopped"
      .showReadoutStack=${args.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      .direction=${args.direction}
      ?alert=${args.alert}
      ?progress=${args.progress}
      .progressMode=${args.progressMode}
      .progressValue=${args.progressValue}
      .positioning=${args.positioning}
    >
      <obi-pump-off-horizontal
        usecsscolor
        slot="icon"
        style="display: block; line-height: 0;"
      ></obi-pump-off-horizontal>
    </obc-automation-button>`;
  },
};

export const ThreeWayValveOpenRight: Story = {
  argTypes: {
    value: {
      control: {type: 'range', min: 0, max: 100, step: 1},
      table: {category: 'Story-specific'},
    },
  } as Partial<Record<string, unknown>>,
  args: {
    value: 70,
  } as Record<string, unknown>,
  render(args) {
    const storyArgs = args as unknown as {
      value: number;
      alert: boolean;
      progress: boolean;
      progressMode: CircularProgressMode;
      progressValue: number;
      showReadoutStack: boolean;
    };
    const readouts: AutomationButtonReadoutStack[] = [
      {
        type: 'value',
        value: 100 - storyArgs.value,
        nDigits: 3,
        unit: '%',
        direction: 'up',
        icon: 'arrow',
      },
      {
        type: 'value',
        value: storyArgs.value,
        nDigits: 3,
        unit: '%',
        direction: 'right',
        icon: 'arrow',
      },
    ];
    const tag: string | null = '#0000';
    return html` <obc-automation-button
      state="open"
      .showReadoutStack=${storyArgs.showReadoutStack}
      .readouts=${readouts}
      .tag=${tag}
      ?alert=${storyArgs.alert}
      ?progress=${storyArgs.progress}
      .progressMode=${storyArgs.progressMode}
      .progressValue=${storyArgs.progressValue}
    >
      <obc-valve-analog-three-way-icon
        value=${storyArgs.value}
        value2=${100 - storyArgs.value}
        slot="icon"
      ></obc-valve-analog-three-way-icon>
    </obc-automation-button>`;
  },
};
