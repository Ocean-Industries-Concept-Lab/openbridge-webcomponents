import type {Meta, StoryObj} from '@storybook/web-components-vite';
import {ObcAutomationTank, TankTrend, TankVariant} from './automation-tank.js';
import './automation-tank.js';
import '../../components/badge/badge.js';
import '../../icons/icon-auto.js';
import '../../icons/icon-command-locked-f.js';
import {html} from 'lit';
import {crossDecorator} from '../../storybook-util.js';
import {BadgeType, BadgeSize} from '../../components/badge/badge.js';

const meta: Meta<typeof ObcAutomationTank> = {
  title: 'Automation/Tanks/Tank',
  tags: ['autodocs'],
  component: 'obc-automation-tank',
  args: {
    value: 9_000,
    max: 10_000,
    trend: TankTrend.fastFalling,
    tag: '#0000',
  },
  argTypes: {
    trend: {
      options: Object.values(TankTrend),
      control: {type: 'radio'},
    },
    value: {
      control: {type: 'range', min: 0, max: 10_000},
    },
    variant: {
      options: Object.values(TankVariant),
      control: {type: 'radio'},
    },
  },
  decorators: [crossDecorator],
} satisfies Meta<ObcAutomationTank>;

export default meta;
type Story = StoryObj<ObcAutomationTank>;

export const Vertical: Story = {
  args: {},
};

export const VerticalWithBadges: Story = {
  render(args) {
    return html`
      <obc-automation-tank
        .value=${args.value}
        .max=${args.max}
        .trend=${args.trend}
        .tag=${args.tag}
      >
        <obc-badge
          slot="badges"
          .size=${BadgeSize.regular}
          .showNumber=${false}
          .type=${BadgeType.automation}
          .showIcon=${true}
        >
          <obi-auto slot="badge-icon"></obi-auto>
        </obc-badge>
        <obc-badge
          slot="badges"
          .size=${BadgeSize.regular}
          .showNumber=${false}
          .type=${BadgeType.automation}
          .showIcon=${true}
        >
          <obi-command-locked-f slot="badge-icon"></obi-command-locked-f>
        </obc-badge>
      </obc-automation-tank>
    `;
  },
};

export const Compact: Story = {
  args: {
    variant: TankVariant.compact,
  },
};
