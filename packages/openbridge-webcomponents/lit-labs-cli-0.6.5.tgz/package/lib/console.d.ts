/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { Console } from 'console';
export type Level = 'error' | 'warn' | 'info' | 'verbose' | 'debug';
/**
 * A Console with a settable log level that controls whether messages are
 * actually output or not.
 */
export declare class LitConsole extends Console {
    logLevel: Level;
    info(message?: unknown, ...optionalParams: unknown[]): void;
    warn(message?: unknown, ...optionalParams: unknown[]): void;
    debug(message?: unknown, ...optionalParams: unknown[]): void;
}
