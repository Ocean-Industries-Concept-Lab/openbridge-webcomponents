/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import type { OptionDefinition } from 'command-line-usage';
export type { OptionDefinition } from 'command-line-usage';
export declare const globalOptions: OptionDefinition[];
/**
 * Performs a simple merge of multiple arguments lists. Does not mutate given
 * arguments lists or arguments.
 *
 * This doesn't perform any validation of duplicate arguments, multiple
 * defaults, etc., because by the time this function is run, the user can't do
 * anything about it. Validation of command and global arguments should be done
 * in tests, not on users machines.
 */
export declare function mergeOptions(optionsLists: OptionDefinition[][]): OptionDefinition[];
