/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { LitCli } from '../lit-cli.js';
export declare const run: ({ cli, packages, frameworks: frameworkNames, manifest, exclude, outDir, }: {
    packages: string[];
    frameworks: string[];
    manifest: boolean;
    outDir: string;
    exclude?: string[];
    cli: LitCli;
}, console: Console) => Promise<1 | undefined>;
