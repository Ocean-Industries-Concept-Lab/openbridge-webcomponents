/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { Command, ReferenceToCommand, ResolvedCommand } from './command.js';
import { LitConsole } from './console.js';
export interface Options {
    cwd: string;
    console?: LitConsole;
    stdin?: NodeJS.ReadableStream;
}
export declare class LitCli {
    readonly commands: Map<string, Command>;
    readonly args: readonly string[];
    readonly console: LitConsole;
    /** The current working directory. */
    readonly cwd: string;
    private readonly stdin;
    constructor(args: string[], options: Options);
    addCommand(command: Command): void;
    run(): Promise<void | import("./command.js").CommandResult>;
    getCommand(commands: Map<string, Command>, args: ReadonlyArray<string>, parentCommandNames?: Array<string>): Promise<{
        commandName: string;
        command: ResolvedCommand;
        argv: string[];
    } | {
        invalidCommand: string;
    } | {
        commandNotInstalled: boolean;
    }>;
    resolveImportForReference(reference: ReferenceToCommand): string | undefined;
    private loadCommandFromPath;
    resolveCommandAsMuchAsPossible(reference: Command): Promise<Command>;
    resolveCommandAndMaybeInstallNeededDeps(maybeReference: Command): Promise<ResolvedCommand | undefined>;
    private installDepWithPermission;
    private getPermissionToInstall;
}
