/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { Command } from '../command.js';
import { LitCli } from '../lit-cli.js';
export type Language = 'ts' | 'js';
export interface InitCommandOptions {
    lang: Language;
    name: string;
    out: string;
}
export declare const makeInitCommand: (cli: LitCli) => Command;
