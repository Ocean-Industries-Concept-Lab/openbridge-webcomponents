/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { ResolvedCommand } from '../command.js';
import { LitCli } from '../lit-cli.js';
export declare const makeHelpCommand: (cli: LitCli) => ResolvedCommand;
