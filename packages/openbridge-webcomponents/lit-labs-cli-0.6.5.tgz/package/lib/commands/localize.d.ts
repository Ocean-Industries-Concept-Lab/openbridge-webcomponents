/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { ReferenceToCommand } from '../command.js';
export declare const localize: ReferenceToCommand;
