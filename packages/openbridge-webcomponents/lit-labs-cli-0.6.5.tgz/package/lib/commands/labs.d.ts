/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { Command } from '../command.js';
import { LitCli } from '../lit-cli.js';
export declare const makeLabsCommand: (cli: LitCli) => Command;
