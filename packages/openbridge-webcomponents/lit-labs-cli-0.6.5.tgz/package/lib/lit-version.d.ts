export declare const litVersion = "3.2.1";
