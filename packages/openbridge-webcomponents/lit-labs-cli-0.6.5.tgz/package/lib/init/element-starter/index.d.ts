/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { FileTree } from '@lit-labs/gen-utils/lib/file-utils.js';
import { CommandResult } from '../../command.js';
import { InitCommandOptions } from '../../commands/init.js';
import { LitCli } from '../../lit-cli.js';
export declare const generateLitElementStarter: (options: InitCommandOptions) => Promise<FileTree>;
export declare const run: (options: InitCommandOptions, console: Console, cli: LitCli) => Promise<CommandResult>;
