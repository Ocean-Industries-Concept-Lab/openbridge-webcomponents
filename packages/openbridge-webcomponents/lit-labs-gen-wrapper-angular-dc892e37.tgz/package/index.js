/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { packageJsonTemplate } from './lib/package-json-template.js';
import { ngPackageJsonTemplate } from './lib/ng-package-json-template.js';
import { tsconfigTemplate } from './lib/tsconfig-template.js';
import { tsconfigLibTemplate } from './lib/tsconfig-lib-json-template.js';
import { publicApiTemplate } from './lib/public-api-template.js';
import { wrapperModuleTemplate } from './lib/wrapper-module-template.js';
import * as path from 'path';
import * as fs from 'fs';
/**
 * Our command for the Lit CLI.
 *
 * See ../../cli/src/lib/generate/generate.ts
 */
export const getCommand = () => {
    return {
        name: 'angular',
        description: 'Generate Angular wrapper components from Lit elements',
        kind: 'resolved',
        async generate(options) {
            return await generateAngularWrapper(options.package);
        },
    };
};
export const generateAngularWrapper = async (pkg) => {
    const litModules = pkg.getLitElementModules();
    if (litModules.length > 0) {
        const packageName = pkg.packageJson.name;
        if (packageName === undefined) {
            throw new Error(`Package must have a package name. Error in ${pkg.rootDir + '/package.json'}`);
        }
        // TODO(justinfagnani): make configurable
        const angularPackageName = `${packageName}-ng`;
        // TODO(justinfagnani): put inside an Angular workspace
        const angularPackageFolder = `${path.basename(pkg.rootDir)}-ng`;
        const readmePath = path.join(pkg.rootDir, 'README.md');
        let readme = undefined;
        if (fs.existsSync(readmePath)) {
            readme = fs.readFileSync(readmePath, 'utf8');
        }
        return {
            [angularPackageFolder]: {
                '.gitignore': gitIgnoreTemplate(litModules),
                'package.json': packageJsonTemplate(angularPackageName, pkg.packageJson),
                'tsconfig.json': tsconfigTemplate(),
                'tsconfig.lib.json': tsconfigLibTemplate(),
                'ng-package.json': ngPackageJsonTemplate(),
                'src/public-api.ts': publicApiTemplate(litModules),
                ...(readme ? { 'README.md': readme } : {}),
                ...wrapperFiles(pkg.packageJson, litModules),
            },
        };
    }
    else {
        throw new Error('No Lit components were found in this package.');
    }
};
const wrapperFiles = (packageJson, litModules) => {
    const wrapperFiles = {};
    for (const { module, declarations } of litModules) {
        const { sourcePath, jsPath } = module;
        wrapperFiles[sourcePath] = wrapperModuleTemplate(packageJson, jsPath, declarations);
    }
    return wrapperFiles;
};
const gitIgnoreTemplate = (litModules) => {
    return litModules
        .map(({ module }) => module.sourcePath.replace(/\\/g, '/'))
        .join('\n');
};
//# sourceMappingURL=index.js.map